import asyncio
import time
import Keys
import random
from pyrogram import Client, filters
from pyrogram.enums import ChatType
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ChatPrivileges


class Group:
    def __init__(self, chat_id, description, time_created, invite_link):
        self.chat_id = chat_id
        self.description = description
        self.time_created = time_created
        self.invite_link = invite_link

    def toString(self):
        print(self.chat_id)
        print(self.description)
        print(self.time_created)
        print(self.invite_link)
        print()


app = Client(
    "app",
    api_id=Keys.api_id,
    api_hash=Keys.api_hash,
    bot_token=Keys.bot_token
)

create_app = Client(
    "my_account",
    api_id=Keys.api_id,
    api_hash=Keys.api_hash,
    bot_token=Keys.bot_token
)

groupList = []


async def create(desc):
    async with create_app:
        chat_number = 0
        for i in groupList:
            if i.description.startswith(desc):
                chat_number = max(int(i.description.split('#')[1]), chat_number)
                if await create_app.get_chat_members_count(i.chat_id) < Keys.MAX_USERS:
                    return i.invite_link
        await asyncio.sleep(random.randint(1, 4) + random.randint(1, 4))
        description = desc + " #" + str(chat_number + 1)
        chat_id = await create_app.create_supergroup(description, description)
        chat_id = chat_id.id
        time_created = int(time.time())
        invite_link = await create_app.export_chat_invite_link(chat_id)
        group = Group(chat_id, description, time_created, invite_link)
        await create_app.add_chat_members(chat_id, ['TeensMenuBot'])
        privileges = ChatPrivileges(can_manage_chat=True,
                                    can_delete_messages=True,
                                    can_restrict_members=True,
                                    can_change_info=True,
                                    can_pin_messages=True)
        await create_app.promote_chat_member(chat_id, 'TeensMenuBot', privileges)

        groupList.append(group)
        return invite_link


@app.on_callback_query()
async def callback_query(client, CallbackQuery):
    await app.delete_messages(chat_id=CallbackQuery.message.chat.id,
                              message_ids=[CallbackQuery.message.id, CallbackQuery.message.id - 1])
    message = await app.send_message(chat_id=CallbackQuery.from_user.id, text='Please Wait.. (10 sec MAX)')
    link = await create(CallbackQuery.data)
    await app.delete_messages(chat_id=CallbackQuery.message.chat.id, message_ids=message.id)
    await app.send_message(
        chat_id=CallbackQuery.from_user.id,
        text='Please Select Group:',
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(text=CallbackQuery.data, url=link)]])
    )


@app.on_message(filters.command('start'))
async def start(client, msg):
    buttons0 = InlineKeyboardMarkup(
        [[InlineKeyboardButton(text="Depression", callback_data="Depression"),
          InlineKeyboardButton(text="AlcoholAbuse", callback_data="Alcohol Abuse")],
         [InlineKeyboardButton(text="Drug Abuse", callback_data="Drug Abuse"),
          InlineKeyboardButton(text="GenderIdentity", callback_data="Gender Identity")],
         [InlineKeyboardButton(text="Cyber Bullying", callback_data="Cyber Bullying"),
          InlineKeyboardButton(text="PhysicalAbuse", callback_data="Physical Abuse")]])
    '''buttons2 = InlineKeyboardMarkup(
        [[InlineKeyboardButton(text="Drug Abuse", callback_data="Drug Abuse"),
          InlineKeyboardButton(text="GenderIdentity", callback_data="Gender Identity")]])
    buttons3 = InlineKeyboardMarkup(
        [[InlineKeyboardButton(text="Cyber Bullying", callback_data="Cyber Bullying"),
          InlineKeyboardButton(text="PhysicalAbuse", callback_data="Physical Abuse")]])'''
    await msg.reply_photo(photo=Keys.LOGO)
    await msg.reply_photo(photo=Keys.buttons0, reply_markup=buttons0)
    '''await msg.reply_photo(photo=Keys.buttons2, reply_markup=buttons2)
    await msg.reply_photo(photo=Keys.buttons3, reply_markup=buttons3)'''


@app.on_message(filters.text)
async def wordsExchange(client, msg):
    message = msg.chat.type
    if message == ChatType.SUPERGROUP:
        text = msg.text.lower()
        member_status = await app.get_chat_member(msg.chat.id, msg.from_user.id)
        if member_status.status == "ChatMemberStatus.ADMINISTRATOR":
            for word, initial in Keys.shortsDict.items():
                text = text.replace(initial, word)
        else:
            for word, initial in Keys.shortsDict.items():
                text = text.replace(word, initial)
        await app.delete_messages(msg.chat.id, msg.id)
        await msg.reply(text=msg.from_user.first_name + ": " + text)
    else:
        await msg.reply(text="press /start")


async def delete(chat_id):
    async with create_app:
        await create_app.delete_supergroup(chat_id)


async def close_groups():
    while True:
        await asyncio.sleep(60)
        for i in groupList:
            # i.toString()
            if int(time.time()) - i.time_created > Keys.EXPIRED_TIME_MIN * 60:
                await delete(i.chat_id)
                groupList.remove(i)
        # print('<---end of loop--->')

if __name__ == '__main__':
    loop = asyncio.new_event_loop()
    # loop.run_until_complete(init())
    loop.create_task(close_groups())
    loop.create_task(app.run())
    loop.run_forever()
